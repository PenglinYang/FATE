# Real-Time Monitoring

## 1. Description

Mainly introduces `FATE Flow` to monitor job running status, Worker execution status, etc., in real time to ensure final consistency