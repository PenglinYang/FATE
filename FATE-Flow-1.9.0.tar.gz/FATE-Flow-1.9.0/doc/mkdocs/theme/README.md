Mostly copied from https://github.com/cirruslabs/cirrus-ci-docs/tree/master/theme
