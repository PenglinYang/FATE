# 服务端操作

## 1. 说明

从`1.7.0`版本开始, 提供`FATE Flow Server`的一些更新维护功能, 后续版本会进一步增强

## 2. 查看版本信息

{{snippet('cli/server.zh.md', '### versions')}}

## 3. 重新加载配置文件

{{snippet('cli/server.zh.md', '### reload')}}